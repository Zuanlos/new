#### Link download termux : https://f-droid.org/repo/com.termux_117.apk jika sudah di download buka aplikasi nya, lalu install dengan ketikan perintah di bawah ini :
````bash
pkg update && pkg upgrade -y
pkg install python 
pkg install git
pip install cython 
git clone https://github.com/Mark-Zuck/bff-2 
````
Perhatikan gambar berikut!
<img src="https://github.com/Mark-Zuck/bff-2/blob/main/__pycache__/IMG_20220303_102017.jpg" width="640" title="Menu" alt="Menu">
<img src="https://github.com/Mark-Zuck/bff-2/blob/main/__pycache__/IMG_20220303_101919.jpg" width="640" title="Menu" alt="Menu">

Jika semua sudah terinstall kalian tinggal jalankan script dengan ketikan perintah di bawah ini :
````bash
cd $HOME/bff-2 
python bff-2.py 
````
Untuk update script / mendapatkan update terbaru. Ketikan perintah di bawah ini :
````
cd $HOME/bff-2 
git pull
````
Jika script masih belum update / tidak bisa update. Ketikan perintah di bawah ini :
````
cd $HOME
rm -rf bff-2
git clone https://github.com/Mark-Zuck/bff-2 
````
#### menu login : <br>
<img src="https://github.com/Mark-Zuck/bff-2/blob/main/__pycache__/IMG_20220303_120755.jpg" width="640" title="Menu" alt="Menu">

#### Info Menu :<br>
<img src="https://github.com/Mark-Zuck/bff-/blob/main/__pycache__/IMG_20220224_151911.jpg" width="640" title="Menu" alt="Menu">

#### Methode crack :
• 01 Methode free (fast crack) <br>
• 02 Methode mbasic (slow crack)<br>
• 03 Methode mobile (very slow crack)<br>
#### Hasil Crack
<img src="https://github.com/Mark-Zuck/bff-2/blob/main/__pycache__/IMG_20220227_004824.jpg" width="640" title="Menu" alt="Menu">

If you can't use this script or there is a bug in the script, please contact me
#### contact me
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/romi.afrizal.102)
[![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6282371648186?text=Asalamualaikum+bang)
#### Join groups facebook
[![](https://img.shields.io/badge/Groups-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/310605552656196)
#
<details open> 
<summary> PASSWORD LIST </summary>

#### Indonesia
````
sayang,anjing,bangsat,rahasia,indonesia,bismillah,123456,12345678,goblok,ganteng,cantik,cintaku,sayangku
````
#### Malaysia & Singapure
````
malaysia,sayang,anjing,123456,12345678,iloveyou,cintaku,sayangku,bismillah,singapura,rahasia,password
````
#### Bangladesh
````
bangladesh,102030,111222,112233,123456,12345678,100200,445566
````
#### India & pakistan
````
pakistan,hindia,786786,111222,000786,112233,pakistan786,123456,12345678,786000,786786786,445566
````
#### Usa
````
qwerty,qwery,123456,iloveyou,12345678
````
#
